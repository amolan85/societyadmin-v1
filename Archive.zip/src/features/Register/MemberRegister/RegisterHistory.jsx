import  { useState, useEffect } from 'react'
import { Badge, Pagination } from '../../../components/Common/ReusableFunction';
import "../../../styles/StaffAttendance.css"
import "../../../styles/Register.css"
import { getBroadcastApi } from '../../../services/BroadcastApi';
import { GetSessionData } from '../../../utils/SessionManagement';
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import {  FiLogIn } from 'react-icons/fi';
import { FiCalendar, FiFilter } from "react-icons/fi";
import { useLoader } from "../../../context/LoaderContext";
import { BsFiletypeCsv, BsFiletypePdf, BsFiletypeXls } from "react-icons/bs";
// import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { RiSecurePaymentFill } from 'react-icons/ri';
import { AiFillProfile } from 'react-icons/ai';
import { BiImport } from 'react-icons/bi';
import { MdReportProblem } from 'react-icons/md';

const RegisterHistory = ({ setActive }) => {
    const [page, setPage] = useState(1);
    const [allRegisterHistory, setAllRegisterHistory] = useState([])
    const [societyId, setSocietyId] = useState("")
    const [show, setShow] = useState(false)
    const { setLoading } = useLoader();
    const [activeTab, setActiveTab] = useState("excel");

    // const all = [
    //     { id: 1, dateTime: "Today, 6:45 PM", icon: <FiLogIn />, type: "Access Log", title: "vehicle tesla model y", status: "Allowed" },
    //     { id: 2, dateTime: "Oct 01,2025, 10:00 PM", icon: <RiSecurePaymentFill />, type: "Payment", title: "vehicle tesla model y", status: "Success" },
    //     { id: 3, dateTime: "Today, 6:45 PM", icon: <RiSecurePaymentFill />, type: "Complaint", title: "vehicle tesla model y", status: "Pending" },
    //     { id: 4, dateTime: "Today, 6:45 PM", icon: <AiFillProfile />, type: "Profile Update", title: "vehicle tesla model y", status: "Completed" },

    // ];
    const all = [
        {
            id: 1,
            dateTime: "Today, 6:45 PM",
            icon: <FiLogIn />,
            type: "Access Log",
            title: "Entered Vehicle: Tesla Model Y",
            status: "Allowed"
        },
        {
            id: 2,
            dateTime: "Oct 01, 2025, 10:00 AM",
            icon: <RiSecurePaymentFill />,
            type: "Payment",
            title: "Maintenance Payment - Oct 2025",
            status: "Success"
        },
        {
            id: 3,
            dateTime: "Sep 28, 2025, 8:30 PM",
            icon: <MdReportProblem />,
            type: "Complaint",
            title: "Complaint: Noise Issue from Unit A-504",
            status: "Pending"
        },
        {
            id: 4,
            dateTime: "Sep 25, 2025, 2:15 PM",
            icon: <AiFillProfile />,
            type: "Profile Update",
            title: "Updated Contact Number",
            status: "Completed"
        },
        {
            id: 5,
            dateTime: "Sep 15, 2025, 5:45 PM",
            icon: <FiLogIn />,
            type: "Access Log",
            title: "Main Gate Exit (Walk-in)",
            status: "Allowed"
        },
        {
            id: 6,
            dateTime: "Sep 01, 2025, 9:30 AM",
            icon: <RiSecurePaymentFill />,
            type: "Payment",
            title: "Clubhouse Booking Payment",
            status: "Success"
        }
    ];
    // Load session data on component mount for get session data
    useEffect(() => {
        SessionData()
    }, [])

    // Get session data and fetch broadcast list
    const SessionData = async () => {
        const data = await GetSessionData()
        console.log(data.data)
        const flats = data.data.flats[0]
        setSocietyId(flats.society_id)

        //call function for get broadcast
        getBroadcast(flats.society_id)
    }

    //function for get broadcast
    const getBroadcast = async (societyId) => {
        try {
            setLoading(true);
            const data = await getBroadcastApi(societyId)
            setAllRegisterHistory(data)
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false);
        }
    }

    //function for get broad cast by id
    const getBroadcastById = (id) => {
        setBroadcastId(id);
        setActive("createbroadcast");    // pehle ID set karo
    };

    const downloadExcel = async () => {
        // create workbook
        const workbook = new ExcelJS.Workbook();

        // add worksheet
        const worksheet = workbook.addWorksheet("Register History");

        // add columns dynamically
        if (allRegisterHistory.length > 0) {
            worksheet.columns = Object.keys(allRegisterHistory[0]).map((key) => ({
                header: key,
                key: key,
                width: 20,
            }));

            // add rows
            allRegisterHistory.forEach((item) => {
                worksheet.addRow(item);
            });
        }

        // header style
        worksheet.getRow(1).font = {
            bold: true,
        };

        // create buffer
        const buffer = await workbook.xlsx.writeBuffer();

        // download file
        saveAs(
            new Blob([buffer], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            }),
            "RegisterHistory.xlsx"
        );
    };

    const downloadCSV = async () => {

        // create workbook
        const workbook = new ExcelJS.Workbook();

        // add worksheet
        const worksheet = workbook.addWorksheet("Register History");

        // add columns dynamically
        if (allRegisterHistory.length > 0) {

            worksheet.columns = Object.keys(allRegisterHistory[0]).map((key) => ({
                header: key,
                key: key,
                width: 20,
            }));

            // add allRegisterHistory
            allRegisterHistory.forEach((item) => {
                worksheet.addRow(item);
            });
        }

        // header style
        worksheet.getRow(1).font = {
            bold: true,
        };

        // generate csv buffer
        const csvBuffer = await workbook.csv.writeBuffer();

        // create blob
        const blob = new Blob([csvBuffer], {
            type: "text/csv;charset=utf-8;",
        });

        // download file
        saveAs(blob, "RegisterHistory.csv");
    };

    const downloadPDF = () => {

        // landscape mode
        const doc = new jsPDF("landscape");

        // PDF Heading
        doc.setFontSize(18);
        doc.text("Register History Report", 14, 15);

        // table columns
        const tableColumn = [
            "Subject",
            "Content",
            "Type",
            "Schedule Date",
            "Status",
        ];

        // table rows
        const tableRows = allRegisterHistory.map((item) => [
            item.title,
            item.message,
            item.type,
            item.scheduled_at,
            item.status,
        ]);

        autoTable(doc, {
            head: [tableColumn],
            body: tableRows,

            // table start after heading
            startY: 25,

            styles: {
                fontSize: 8,
                cellPadding: 3,
            },

            headStyles: {
                fillColor: [13, 110, 253],
            },

            theme: "grid",
        });

        doc.save("BroadcastData.pdf");
    };

    const handleExport = () => {

        if (activeTab === "excel") {
            downloadExcel();
            setShow(false)
        }

        else if (activeTab === "csv") {
            downloadCSV();
            setShow(false)
        }

        else
            if (activeTab === "pdf") {
                downloadPDF();
                setShow(false)
            }
    };

    //for pagination
    const per = 5, total = Math.ceil(all.length / per);
    const rows = all.slice((page - 1) * per, page * per);

    return (
        <>
            <div className="pg sa-wrap">

                {/* Header */}
                {/* <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                    <h4 className="sa-title">Broadcast</h4>
                    <div className="d-flex gap-2">
                        <button className="btn-ol" onClick={() => setShow(true)}>⬇ Export</button>
                    </div>
                </div> */}
                <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">

                    {/* Left Section */}
                    <div className="d-flex flex-wrap align-items-center gap-3">

                        {/* Search */}
                        <div className="position-relative">

                            {/* <FiSearch className="re-search-icon" /> */}

                            <input
                                type="text"
                                className="form-control search-input "
                                placeholder="Search history..."
                            />

                        </div>

                        {/* Last 30 Days */}
                        <button className="btn btn-sm filter-btn d-flex align-items-center gap-2 bg-white">

                            <FiCalendar size={14} />

                            Last 30 Days

                        </button>

                        {/* Filter Dropdown */}
                        <div className="dropdown">

                            <button
                                className="btn btn-sm filter-btn d-flex align-items-center gap-2 bg-white"
                                data-bs-toggle="dropdown"
                            >
                                <FiFilter size={14} />

                                All Types
                            </button>

                            <div className="dropdown-menu p-3 shadow border-0 rounded-4 re-filter-dropdown">

                                {/* Header */}
                                <div className="d-flex justify-content-between align-items-center mb-3">

                                    <small className="text-muted fw-semibold">
                                        Filter by Type
                                    </small>

                                    <button className="btn btn-link p-0 text-decoration-none small" style={{ fontSize: "17px" }}>
                                        Select All
                                    </button>

                                </div>

                                {/* Checkbox List */}
                                <div className="d-flex flex-column gap-2">

                                    <div className="form-check">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            defaultChecked
                                        />

                                        <label className="form-check-label" style={{ fontSize: "15px" }}>
                                            Access Log
                                        </label>
                                    </div>

                                    <div className="form-check">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            defaultChecked
                                        />

                                        <label className="form-check-label" style={{ fontSize: "15px" }}>
                                            Payments
                                        </label>
                                    </div>

                                    <div className="form-check">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            defaultChecked
                                        />

                                        <label className="form-check-label" style={{ fontSize: "15px" }}>
                                            RegisterHistory
                                        </label>
                                    </div>

                                    <div className="form-check">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            defaultChecked
                                        />

                                        <label className="form-check-label" style={{ fontSize: "15px" }}>
                                            System Updates
                                        </label>
                                    </div>

                                    <div className="form-check">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                        />

                                        <label className="form-check-label" style={{ fontSize: "15px" }}>
                                            Notices
                                        </label>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    {/* Export Button */}
                    <div className="d-flex gap-2">

                        <button className="btn-ol" onClick={() => setShow(true)}><BiImport /> Export</button>
                        <button className="btn btn-primary btn-sm" onClick={() => setActive("memberDetails")}>Back</button>
                    </div>
                </div>
                {/* Table */}
                <div className="sv-card p-0 overflow-hidden">
                    <div className="sa-table-wrap">
                        {/* <table className="sv-tbl">
                            <thead>
                                <tr>
                                    {["Date & Time", "Type", "Title", "Status"]
                                        .map(h => <th key={h}>{h}</th>)}
                                </tr>
                            </thead>
                            <tbody>
                                {rows.map((s, i) => (
                                    <tr className="text-start" key={s.id}>

                                        <td className="sa-name">{s.dateTime}</td>

                                        <td className="sa-muted">{s.icon} {s.type}</td>
                                        <td className="sa-muted">{s.title}</td>
                                        <td>
                                            <Badge label={s.status}
                                                c={
                                                    s.status === "Allowed"
                                                        ? "blue"
                                                        : s.status === "Success"
                                                            ? "green"
                                                            : s.status === "Pending"
                                                                ? "orange"
                                                                : s.status === "Completed"
                                                                    ? "gray"
                                                                    : "gray"
                                                }
                                            />
                                        </td>



                                    </tr>
                                ))}
                            </tbody>

                        </table> */}
                        <table className="sv-tbl">
                            <thead>
                                <tr>
                                    <th>DATE & TIME</th>
                                    <th>TYPE</th>
                                    <th>TITLE</th>
                                    <th>STATUS</th>
                                </tr>
                            </thead>

                            <tbody>
                                {rows.map((s) => (
                                    <tr key={s.id} className="text-start">

                                        <td className="sa-date">
                                            {s.dateTime}
                                        </td>

                                        <td>
                                            <div className="type-box">
                                                <span className={`type-icon
                            ${s.type === "Access Log" ? "green" : ""}
                            ${s.type === "Payment" ? "blue" : ""}
                            ${s.type === "Complaint" ? "red" : ""}
                            ${s.type === "Profile Update" ? "gray" : ""}
                        `}>
                                                    {s.icon}
                                                </span>

                                                <span className="type-text">
                                                    {s.type}
                                                </span>
                                            </div>
                                        </td>

                                        <td className="title-text">
                                            {s.title}
                                        </td>

                                        <td>
                                            <Badge
                                                label={s.status}
                                                c={
                                                    s.status === "Allowed"
                                                        ? "blue"
                                                        : s.status === "Success"
                                                            ? "green"
                                                            : s.status === "Pending"
                                                                ? "yellow"
                                                                : s.status === "Completed"
                                                                    ? "gray"
                                                                    : "gray"
                                                }
                                            />
                                        </td>

                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination */}
                    <Pagination
                        page={page}
                        total={total}
                        onChange={setPage}
                    />

                </div>
            </div>
            {show && (
                <>

                    <div className="modal-backdrop fade show"></div>


                    <div className="modal show d-block">
                        <div className="modal-dialog modal-md">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h1 className="modal-title fs-5">Export Data</h1>


                                    <button
                                        type="button"
                                        className="btn-close"
                                        onClick={() => setShow(false)}
                                    ></button>
                                </div>


                                <div className="modal-body">
                                    <h6 className=" text-start" style={{ fontWeight: "bold" }}>Select Format</h6>
                                    <div className="row mb-4">

                                        {/* Excel */}
                                        <div className="col-md-4">
                                            <div
                                                className={`format-card text-center p-3 rounded-3 ${activeTab === "excel" ? "active-format" : ""
                                                    }`}
                                                onClick={() => { setActiveTab("excel") }}
                                            >
                                                <BsFiletypeXls
                                                    className={
                                                        activeTab === "excel"
                                                            ? "text-primary"
                                                            : "text-secondary"
                                                    }
                                                    size={20}
                                                />

                                                <p
                                                    className={`fw-semibold mb-0 mt-1 ${activeTab === "excel"
                                                        ? "text-primary"
                                                        : "text-secondary"
                                                        }`}
                                                >
                                                    Excel
                                                </p>
                                            </div>
                                        </div>

                                        {/* CSV */}
                                        <div className="col-md-4">
                                            <div
                                                className={`format-card text-center p-3 rounded-3 ${activeTab === "csv" ? "active-format" : ""
                                                    }`}
                                                onClick={() => { setActiveTab("csv") }}
                                            >
                                                <BsFiletypeCsv
                                                    className={
                                                        activeTab === "csv"
                                                            ? "text-primary"
                                                            : "text-secondary"
                                                    }
                                                    size={20}
                                                />

                                                <p
                                                    className={`fw-semibold mb-0 mt-1 ${activeTab === "csv"
                                                        ? "text-primary"
                                                        : "text-secondary"
                                                        }`}
                                                >
                                                    CSV
                                                </p>
                                            </div>
                                        </div>

                                        {/* PDF */}
                                        <div className="col-md-4">
                                            <div
                                                className={`format-card text-center p-3 rounded-3 ${activeTab === "pdf" ? "active-format" : ""
                                                    }`}
                                                onClick={() => { setActiveTab("pdf") }}
                                            >
                                                <BsFiletypePdf
                                                    className={
                                                        activeTab === "pdf"
                                                            ? "text-primary"
                                                            : "text-secondary"
                                                    }
                                                    size={20}
                                                />

                                                <p
                                                    className={`fw-semibold mb-0 mt-1 ${activeTab === "pdf"
                                                        ? "text-primary"
                                                        : "text-secondary"
                                                        }`}
                                                >
                                                    PDF
                                                </p>
                                            </div>
                                        </div>

                                    </div>


                                    <h6 className=" text-start fw-bold">Data Range</h6>


                                    <div className="range-card active-range d-flex justify-content-between align-items-center mb-3">
                                        <div className="d-flex align-items-center gap-3">
                                            <input className="form-check-input" type="radio" checked />
                                            <h6 className='fw-bold mt-1'>All Data</h6>
                                        </div>

                                        <span className="text-muted mt-1"><h6>{allRegisterHistory.length} records</h6></span>
                                    </div>


                                    <div className="range-card d-flex justify-content-between align-items-center mb-3">
                                        <div className="d-flex align-items-center gap-3">
                                            <input className="form-check-input" type="radio" />
                                            <h6 className="fw-bold mt-1">Current Search results</h6>
                                        </div>

                                        <h6 className="text-muted mt-1">40 records</h6>
                                    </div>


                                    <div className="range-card d-flex align-items-center gap-3">
                                        <div className="d-flex align-items-center gap-3">
                                            <input className="form-check-input" type="radio" />
                                            <h6 className="fw-bold mt-1">Custom date range</h6>
                                        </div>

                                    </div>

                                </div>


                                <div className="modal-footer">

                                    <button className="btn-sm btn btn-outline-secondary" onClick={() => setShow(false)}>
                                        Cancel
                                    </button>

                                    <button className="btn btn-sm btn-primary" onClick={handleExport}>
                                        <i className="bi bi-download me-2"></i>
                                        Export Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>


                </>
            )}

        </>
    )
}

export default RegisterHistory